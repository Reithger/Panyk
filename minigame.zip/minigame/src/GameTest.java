

public class GameTest {

	public static void main(String[] args){
		
		MiniGame.startGame();

	}

}
