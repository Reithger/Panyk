import java.io.File;
import java.io.IOException;

public class MiniGame{
	
    //-----------------------
    public static void startGame(){
    	
    	String os = System.getProperty("os.name");
    	String DIRECTORY = System.getProperty("user.dir").replaceAll("\\\\", "/") + "/";
    	
    	//if a windows system
    	if(os.charAt(0) == 'W') {
    		
    		try {
    			
    			ProcessBuilder pb = new ProcessBuilder("cmd.exe", "/C", "Start", "runFlappy.bat");
    			File dir = new File(DIRECTORY + "flappybird/");
    			pb.directory(dir);
    			Process p = pb.start();
			} catch (IOException e) {
				e.printStackTrace();
			}
    			
    	}
    	//if a mac/linux
    	else {
    		
    		String[] cmd = new String[]{"/bin/sh", DIRECTORY + "flappybird/runFlappy.sh"};
    		try {
				Process pr = Runtime.getRuntime().exec(cmd);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		
    	}
    	
    	
    }
    
    
    
}//-----------------